// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import type { NextApiRequest, NextApiResponse } from 'next'


export default function handler(
  req: NextApiRequest,
  res: NextApiResponse,
) {
  res.status(200).json([{ "problemId": 1, "name": 'Initialize Integer', "prompt": 'Displays an integer saved to a variable to ensure correct functioning.',"number": '1'}
    , { "problemId": 2, name: 'Initialize Double', prompt: 'Displays a double saved to a variable to ensure correct functioning.', number: "2"}]);
}
