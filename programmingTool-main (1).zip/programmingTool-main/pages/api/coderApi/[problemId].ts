import {NextApiRequest, NextApiResponse} from "next";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    const {problemId} = req.query;

    if (typeof problemId === "string") {
        const problems: any = [{ "problemId": 1, "name": 'Initialize Integer', "prompt": 'Displays an integer saved to a variable to ensure correct functioning.',"number": '1'}
            , { "problemId": 2, name: 'Initialize Double', prompt: 'Displays a double saved to a variable to ensure correct functioning.', number: "2"  }];

        res.status(200).json(problems[parseInt(problemId)]);

    }
}