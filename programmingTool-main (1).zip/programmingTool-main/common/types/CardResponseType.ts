export interface CardResponseType {
    problemId: number,
    name: string,
    prompt: string,
    number: number,
}